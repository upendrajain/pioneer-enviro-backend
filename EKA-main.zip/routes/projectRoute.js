const router = require("express").Router();

const { AddUser, Checking, listUser, updateProjectDetailsByMember } = require("../Controller/projectCtrl");
const { staffMiddleware } = require("../Middleware/authMiddleware")

router.get("/get", staffMiddleware, Checking);
router.get("/list", staffMiddleware, listUser);
router.post("/add", staffMiddleware, AddUser);
router.put("/update", updateProjectDetailsByMember);

module.exports = router;