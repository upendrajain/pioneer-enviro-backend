const mongoose = require("mongoose")
const rolemdels = require("../Models/RoleModel")

const addroles = async(req,res,next)=>{
    try{
        const user = await rolemodels.findOne()
    }catch(error){

    }

}