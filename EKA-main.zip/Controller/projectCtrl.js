const projectModel = require("../Models/projectModel");
const settingModel = require("../Models/SettingModel");
const jwt = require("jsonwebtoken");
const nodemailer = require('nodemailer');

const Checking = async (req, res, next) => {
  try {
    const Checkuser = await projectModel.findOne({
      $or: [{ Khasra: req.query.Khasra }, { Survey: req.query.Survey }],
    });

    if (Checkuser) {
      res.status(200).json({
        exists: true,
        message: "record exists",
        data: Checkuser,
      });
    } else {
      res.status(200).json({
        exists: false,
        message: "No match found. Record for Confirmation",
      });
    }
    next();
  } catch (error) {
    res.status(200).json({
      error: true,
      message: error.message,
      data: {},
    });
    next();
  }
};

const AddUser = async (req, res, next) => {
  try {
    const User = await projectModel.findOne({
      $or: [{ Khasra: req.body.Khasra }, { Survey: req.body.Survey }],
    });
    if (User) {
      res.status(200).json({
        exists: true,
        message: "record exists",
        // data: User,
      });
    }

    req.body.staff_id = req.staff_id;

    const newUser = await projectModel.create(req.body);

    // const emailCred = await settingModel.findOne({ companyId: req.companyId });
    const emailCred = await settingModel.findOne();
    let config = {
      service: emailCred.service,
      host: emailCred.smtpHostt,
      port: emailCred.smtpPort,
      secure: false,
      auth: {
        user: emailCred.email,
        pass: emailCred.password,
      },
    };
    const transporter = nodemailer.createTransport(config);
    let data = {
      from: emailCred.email,
      to: req.body.email,
      subject: "Request for Complete Project Details",
      text: `
            Dear [Recipient's Name],

Greetings of the day!

Thank you for reaching out to us. To proceed further, we kindly request you to share the complete details of your project. This will help us better understand your requirements and provide you with the most accurate support.

Please share the project description using the following link:
http://localhost:5173/client-form?token=${jwt.sign(
        {
          project: newUser._id,
        },
        "project_id"
      )}

We look forward to reviewing your input and collaborating with you on your project.

Best regards,  
[Your Full Name]  
[Your Position]  
[Your Company Name]  
[Contact Information]
`,
    };
    transporter.sendMail(data, async (err, info) => {
      if (err) {
        //                const save = await typeModel.create(data)
        res.data = {
            token: jwt.sign(
            {
              project: newUser._id
            },
            "project_id"
          ),
        };
        res.error = true;
        res.message = err.message;
        res.status_Code = 500;
        next();

        //              throw new Error(err.message);
      } else {
        req.body.createdBy = req.staff;
        req.body.updatedBy = req.staff;
        // const save = await typeModel.create(req.body);
        res.data = {
          token: jwt.sign(
            {
              project: newUser._id
            },
            "project_id"
          ),
        };
        res.message = "Mail send successfully!";
        res.status_Code = 200;
        next();
      }
    });

    res.status(200).json({
      exists: true,
      message: "Done",
      data: {newUser,token: jwt.sign(
            {
              project: newUser._id
            },
            "project_id"
          )}
    });
    next();
  } catch (error) {
    res.status(200).json({
      error: true,
      message: error.message,
      data: {},
    });
    next();
  }
};

const listUser = async (req, res, next) => {
    try {
        const { project_name, city, state, country, status, page, count } = req.query;
        let filter = {};
        if(project_name) {
            filter = { project_name: new RegExp(project_name, 'i') }
        }
        if(city) {
            filter = { ...filter, city }
        }
        if(state) {
            filter = { ...filter, state }
        }
        if(country) {
            filter = { ...filter, country }
        }
        const data = await projectModel.find(filter).skip(page * count).limit(count).select("project_name user_id staff_id Address createdAt").populate('user_id staff_id',"name");
        res.json({
            error: false,
            message: "Data fetched successfully",
            data
        })
    }
    catch(error) {
        res.json({
            error: true,
            message: error.message
        })
    }
}

const updateProjectDetailsByMember = async (req, res, next) => {
  try {
    let token = req.headers.authorization.split(" ")[1];
    let decode = jwt.verify(token, "project_id");
    console.log("Decoded JWT:", decode.project);
    console.log("Request Body:", req.body);
    const project = await projectModel.findById(decode.project);
    if (!project)
      throw new Error("Sorry Your session has expired. Please Login first");
    // if (project.status != "Approved")
    //   throw new Error(
    //     "Sorry You are not allowed for performing any action please contact admin!"
    //   );
    await projectModel.findByIdAndUpdate(decode.project, { $set: req.body.formData },
       {new:true});

    res.json({
      error: false,
      message: "Project Details Uploaded Successfully!",
    });
  } catch (error) {
    res.json({
      error: true,
      message: error.message,
    });
  }
};

module.exports = {
    AddUser,
    Checking,
    listUser,
    updateProjectDetailsByMember
}