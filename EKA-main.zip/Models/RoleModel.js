const mongoose = require("mongoose")

const RoleModel = new mongoose.Schema({
    
})